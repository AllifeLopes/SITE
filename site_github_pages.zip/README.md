# Site para GitHub Pages

## Como publicar
1. Crie uma conta no GitHub
2. Crie um repositório novo, por exemplo: `meu-site`
3. Envie o arquivo `index.html` para esse repositório
4. Vá em **Settings > Pages**
5. Em **Branch**, escolha `main` e a pasta `/root`
6. Clique em **Save**
7. Seu site ficará disponível em algo parecido com:
   `https://seuusuario.github.io/meu-site/`

## Personalização rápida
- Troque `All Tech` pelo seu nome
- Troque `seuemail@exemplo.com` pelo seu e-mail
- Edite os textos como quiser
